linkmap <- function(X, D, Ds) {
	maps.draw <- function(panel){
		dev.hold()
		par(maps.par)
		plot(X)
		par(xpd=T)
		n = length(X[,1])
		s1 <- panel$s1
		s2 <- panel$s2
		s3 <- panel$s3
		if(length(s1) == 0){
			s1 = 0
		}
		if(length(s2) == 0){
			s2 = 0
		}
		if(length(s3) == 0){
			s3 = 0
		}
		if(s2 < s1){
			s2 <- s1
		}
		if(s3 < s2){
			s3 <- s2
		}
		for(j in 1:n){
			for(i in 1:j){
				if(i != j){
					if(D[i,j] < s3){
						if(D[i,j] >= s2){
							segments(X[i,1],X[i,2],X[j,1],X[j,2], lty=3, col=1, lwd=1)
						}else if(D[i,j] >= s1){
							segments(X[i,1],X[i,2],X[j,1],X[j,2], lty=1, col=1, lwd=1)
						}else{
							segments(X[i,1],X[i,2],X[j,1],X[j,2], lty=1, col=1, lwd=3)
						}
					}
				}
			}
		}
		#max(X[,1]), (max(X[,2]-min(X[,2])))/2
		legend("topleft",  c("0 <= x < S1", "S1 <= x < S2", "S2 <= x <  S3"), lwd=c(3,1,1), lty=c(1,1,3))
		dev.flush()
		panel
	}
	maps.par = par(no.readonly=T)
	min <- 0
	max <- max(D)
	panel <- rp.control(title = "Thresholds", slo=0.5, int=1.0, size=c(400, 400))
	rp.slider(panel, var=s1, from=min, to=max, title="S1", action=maps.draw, pos=c(5, 5, 290, 70), showvalue=TRUE)
	rp.slider(panel, var=s2, from=min, to=max, title="S2", action=maps.draw, pos=c(5, 70, 290, 90), showvalue=TRUE)
	rp.slider(panel, var=s3, from=min, to=max, title="S3", action=maps.draw, pos=c(5, 135, 290, 110), showvalue=TRUE)

}